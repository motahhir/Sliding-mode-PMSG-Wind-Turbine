%%%%%%%paramétre de la machine MSAP
Rs=6.25e-3 ;
Ld=4.229e-3 ;
Lq=4.229e-3;
p=75  ; 
flux=11.1464;

%%%%%% filtre
Lf=5e-4;
Rf=0;
%%%%%% bus continu
Cbus=0.06;
Vdcref=5000

%%%%% temps ech
Ts=10e-6;
eps=0.707;

%%%donnes de la  turbine
R=58;         
rho=1.225;
J=10000;
F=0;
cpmax=0.35;
lamopt=7.07;
K=1;
c1=0.5176;
c2=116;
c3=0.4;
c4=5;
c5=21;
c6=0.0086;
% % regulateur de vitesse de la turbine  
wnvitesse=2*pi/0.09;
kpv=2*eps*wnvitesse*J;
kiv=wnvitesse*wnvitesse*J;

% regulation du courant reseau idf et iqf
%%regulateur courant Idf
Widr=2*pi/40e-03;
Kid=Lf*((Widr)^2);
Kpd=(2*eps*Lf*Widr)-Rs;
%%regulateur courant Iqf
Wiqr=2*pi/40e-03;
Kiq=Lf*((Wiqr)^2);
Kpq=(2*eps*Lf*Wiqr)-Rs;
%%regulateur bus continu
Wudc=2*pi/200e-03;
Ki=Cbus*((Wudc)^2);
Kp=Cbus*2*eps*Wudc;
%%%%%PLL0.038648
wpll=2*pi/0.07;
kpPLL=2*eps*wpll;
DiPLL=2*eps/(wpll);
kiPLL=kpPLL/DiPLL;
%%%%%%regulateur puissance reactive
KiQr=0.2;
KpQr=0.017;
% parametre SMC CCM
Kdn=500e60
Kqn=50000e10


