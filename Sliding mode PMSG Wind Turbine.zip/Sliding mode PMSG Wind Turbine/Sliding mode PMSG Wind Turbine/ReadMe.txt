This folder contains :

- Wind Turbine Model

- PMSG Model

- Sliding Mode Control for Wind turbine based on the  PMSG 




Please cite this work as: 



1.	F. Echiheb, Y. Ihedrane, B. Bossoufi, M.Bouderbala, S.Motahhir, M. Masud, S. Aljahdali, M. El Ghamrasni. Robust Sliding-Backstepping mode Control of a wind system based on the DFIG Generator. Scientific Reports, Vol.12, pp 11782, July 2022.

2.	Majout, B.; El Alami, H.; Salime, H.; Zine Laabidine, N.; El Mourabit, Y.; Motahhir, S.; Bouderbala, M.; Karim, M.; Bossoufi, B. A Review on Popular Control Applications in Wind Energy Conversion System Based on Permanent Magnet Generator PMSG. Energies 2022, 15, 6238. https://doi.org/10.3390/en15176238 

3.	Majout, B.; Bossoufi, B.; Bouderbala, M.; Masud, M.; Al‐Amri, J.F.; Taoussi, M.; El Mahfoud, M.; Motahhir, S.; Karim, M. Improvement of PMSG‐based Wind Energy Conversion System Using Developed Sliding Mode Control. Energies 2022, 15, 1625. https://doi.org/10.3390/en15051625 

4.	Alami, Houda E., Badre Bossoufi, Saad Motahhir, Eman H. Alkhammash, Mehedi Masud, Mohammed Karim, Mohammed Taoussi, Manale Bouderbala, Mouna Lamnadi, and Mohammed El Mahfoud. 2022. "FPGA in the Loop Implementation for Observer Sliding Mode Control of DFIG-Generators for Wind Turbines" Electronics 11, no. 1: 116. https://doi.org/10.3390/electronics11010116. 








For more papers and works please visit : https://sites.google.com/usmba.ac.ma/motahhir/home





